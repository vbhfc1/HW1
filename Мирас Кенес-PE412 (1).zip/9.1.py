# s="Пример строки"
# print(s.upper())
# print(s[:3]) 
# t=(1,2,3,4,5)
# print(t[1:3]) 
# words=["яблоко","банан","апельсин"]
# words.sort()
# print(words) 
# elements=[1,"строка",3.14,True]
# print(len(elements)) 
# sentence="это строка из слов"
# words=sentence.split()
# print(words) 
# numbers=[5,8,2,1,9]
# print(max(numbers)) 
# strings=["раз","два","три"]
# print(",".join(strings)) 
